let isAdmin = localStorage.getItem('isAdmin') === "true";


function showSection(sectionId) {
    // Ocultar todas las secciones
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });

    // Mostrar la sección seleccionada
    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.classList.add('active');
        selectedSection.style.display = 'block';
    }
}


// Inicializamos las variables globales
let coordenadasSeleccionadas = null;
let markers = [];  // Arreglo para almacenar los marcadores
let infoWindows = []; // Arreglo para almacenar las ventanas de información (para cada marcador)

// Función para inicializar el mapa
function initMap() {
    const centroBogota = { lat: 4.60971, lng: -74.08175 }; // Coordenadas de Bogotá
    map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: centroBogota,
    });

    // Evento para capturar las coordenadas al hacer clic en el mapa
    map.addListener('click', function(event) {
        coordenadasSeleccionadas = {
            lat: event.latLng.lat(),
            lng: event.latLng.lng()
        };

        // Copiar las coordenadas a los campos de latitud y longitud del formulario
        document.getElementById('latitud').value = coordenadasSeleccionadas.lat;
        document.getElementById('longitud').value = coordenadasSeleccionadas.lng;

        // Cambiar automáticamente a la sección "Agregar Árbol"
        showSection('agregar-arbol');
        
        // Mostrar un mensaje para confirmar que se seleccionó una ubicación
        alert('Coordenadas seleccionadas: ' + coordenadasSeleccionadas.lat + ', ' + coordenadasSeleccionadas.lng);
    });
}


// Validar los datos del formulario
function validarFormulario(formData, coordenadasSeleccionadas) {
    if (!coordenadasSeleccionadas) {
        return 'Por favor, selecciona un punto en el mapa para obtener las coordenadas.';
    }

    if (formData.lat !== coordenadasSeleccionadas.lat || formData.lng !== coordenadasSeleccionadas.lng) {
        return 'Por favor, asegúrate de que las coordenadas coincidan con las seleccionadas en el mapa.';
    }

    if (!formData.nombre || !formData.descripcion) {
        return 'El nombre y la descripción del árbol son obligatorios.';
    }

    return null; // Si no hay errores, retorna null
}



// Crear un marcador en el mapa
function crearMarcador(map, formData, markers, infoWindows) {
    const marker = new google.maps.Marker({
        position: { lat: formData.lat, lng: formData.lng },
        map: map,
        title: formData.nombre,
    });

    // Crear una ventana de información
    const infoWindow = new google.maps.InfoWindow({
        content: `<div>
                    <h3>${formData.nombre}</h3>
                    <p>${formData.descripcion}</p>
                    <button onclick="eliminarMarcador(${markers.length})">Eliminar este árbol</button>
                  </div>`,
    });

    // Asociar la ventana de información al marcador
    marker.addListener('click', function () {
        infoWindow.open(map, marker);
    });

    // Agregar el marcador y la ventana al almacenamiento
    markers.push(marker);
    infoWindows.push(infoWindow);
}

// Resetear el formulario
function resetearFormulario(formElement) {
    formElement.reset();
    coordenadasSeleccionadas = null;
}

class NotificationService {
    constructor() {
        this.notificationContainer = document.getElementById('notificacion');
    }

    // Mostrar notificación
    show(message, type = 'info') {
        this.notificationContainer.textContent = message;
        this.notificationContainer.className = `notificacion ${type}`;
        this.notificationContainer.style.display = 'block';

        // Ocultar después de unos segundos
        setTimeout(() => {
            this.hide();
        }, 3000);
    }

    // Ocultar notificación
    hide() {
        this.notificationContainer.style.display = 'none';
    }
}

// Crear una instancia del servicio de notificaciones
const notificationService = new NotificationService();

// Evento al enviar el formulario
document.getElementById('form-agregar-arbol').addEventListener('submit', function (e) {
    e.preventDefault();

    // Obtener los valores del formulario
    const formData = {
        nombre: document.getElementById('nombre-arbol').value,
        descripcion: document.getElementById('descripcion-arbol').value,
        lat: parseFloat(document.getElementById('latitud').value),
        lng: parseFloat(document.getElementById('longitud').value),
    };

    // Validar el formulario
    const error = validarFormulario(formData, coordenadasSeleccionadas);
    if (error) {
        notificationService.show(error, 'error'); // Mostrar error con el servicio de notificaciones
        return;
    }

    // Crear el marcador en el mapa
    crearMarcador(map, formData, markers, infoWindows);

    // Resetear el formulario
    resetearFormulario(document.getElementById('form-agregar-arbol'));

    // Notificación de éxito
    notificationService.show('Árbol agregado correctamente', 'success');
});


// Función para eliminar un marcador individualmente
function eliminarMarcador(index) {
    const marker = markers[index];
    marker.setMap(null); // Eliminar el marcador del mapa
    markers.splice(index, 1); // Eliminar el marcador del arreglo de markers
    infoWindows[index].close(); // Cerrar la ventana de información
    infoWindows.splice(index, 1); // Eliminar la ventana de información del arreglo
    alert('El marcador ha sido eliminado.');
}

// Función para eliminar todos los marcadores
function eliminarTodosMarcadores() {
    for (let i = 0; i < markers.length; i++) {
        markers[i].setMap(null); // Eliminar el marcador del mapa
    }
    markers = []; // Vaciar el arreglo de marcadores

    // Limpiar los campos de latitud y longitud del formulario
    document.getElementById('latitud').value = '';
    document.getElementById('longitud').value = '';

    alert('Todos los marcadores han sido eliminados.');
}

function limpiarDatos() {
    // Aquí puedes implementar la lógica para limpiar marcadores o datos del mapa.
    alert('Datos del mapa limpiados');
}




document.getElementById('form-agregar-arbol').addEventListener('submit', function(e) {
    e.preventDefault();
    const nombreArbol = document.getElementById('nombre-arbol').value;
    const latitud = parseFloat(document.getElementById('latitud').value);
    const longitud = parseFloat(document.getElementById('longitud').value);

    if (!isNaN(latitud) && !isNaN(longitud)) {
        // Crear un marcador en el mapa
        const marker = new google.maps.Marker({
            position: { lat: latitud, lng: longitud },
            map: map,
            title: nombreArbol
        });

        alert('Árbol agregado correctamente');
    } else {
        alert('Por favor, introduce coordenadas válidas.');
    }
});

// Definimos un arreglo de retos disponibles
const retosDisponibles = [
    { nombre: "Plantar 5 árboles", descripcion: "Planta al menos 5 árboles en la ciudad de Bogotá.", puntos: 200, completado: false },
    { nombre: "Limpiar un parque", descripcion: "Participa en una jornada de limpieza en un parque local.", puntos: 150, completado: false },
    { nombre: "Promover la sostenibilidad", descripcion: "Comparte 5 publicaciones sobre sostenibilidad en tus redes sociales.", puntos: 100, completado: false },
    { nombre: "Donar para proyectos ecológicos", descripcion: "Haz una donación de al menos $50 para proyectos ecológicos.", puntos: 300, completado: false },
    { nombre: "Árboles en la escuela", descripcion: "Planta un árbol en tu escuela o universidad y comparte fotos del proceso.", puntos: 500, completado: false },
];

// Array de recompensas disponibles
const recompensasDisponibles = [
    { nombre: "Descuento en Tienda Ecológica", puntos: 100, descripcion: "Obtén un descuento del 10% en tu compra." },
    { nombre: "Plantar un Árbol en Tu Nombre", puntos: 200, descripcion: "Recibe un certificado por haber plantado un árbol." },
    { nombre: "Cuaderno Ecológico", puntos: 300, descripcion: "Recibe un cuaderno hecho de materiales reciclados." },
    { nombre: "Donación a Fundación Ecológica", puntos: 500, descripcion: "Haz una donación de $50 para proyectos ecológicos." },
    { nombre: "Experiencia de Ecoturismo", puntos: 1000, descripcion: "Participa en una jornada de ecoturismo." },
];


function registrarUsuario(nombreUsuario) {
    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    const nuevoUsuario = {
        id: Date.now(),
        nombre: nombreUsuario,
        puntos: 0,
        evidencias: []
    };

    usuarios.push(nuevoUsuario);
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    alert(`Usuario ${nombreUsuario} registrado exitosamente.`);
    console.log("Usuarios registrados:", JSON.parse(localStorage.getItem("usuarios")));

}


// Función para cargar los retos disponibles en la sección de retos
function cargarRetosDisponibles() {
    const retosLista = document.getElementById('retos-lista');
    retosLista.innerHTML = ""; // Limpiar la lista antes de agregar nuevos retos

    retosDisponibles.forEach((reto, index) => {
        const div = document.createElement('div');
        div.classList.add('reto');
        div.innerHTML = `
            <h3>${reto.nombre}</h3>
            <p>${reto.descripcion}</p>
            <p><strong>${reto.puntos} puntos</strong></p>
            <button onclick="activarReto(${index})">Iniciar Reto</button>
        `;
        retosLista.appendChild(div);
    });

    if (isAdmin) {
        const btnAgregarReto = document.createElement("button");
        btnAgregarReto.textContent = "Agregar Reto";
        btnAgregarReto.onclick = agregarRetoAdmin;
        retosLista.appendChild(btnAgregarReto);
    }
}



// Función para activar un reto y añadir puntos al usuario
function activarReto(index) {
    const reto = retosDisponibles[index];
    puntosUsuario += reto.puntos;
    alert(`Reto ${reto.nombre} activado. Has ganado ${reto.puntos} puntos.`);
    cargarRecompensas();  // Actualizar la lista de recompensas
}

// Función para reclamar una recompensa
function reclamarRecompensa(puntos) {
    if (puntosUsuario >= puntos) {
        puntosUsuario -= puntos;
        alert("Recompensa reclamada con éxito.");
        cargarRecompensas();  // Actualizar los puntos y recompensas
    } else {
        alert("No tienes suficientes puntos para reclamar esta recompensa.");
    }
}

// Puntos acumulados del usuario
let puntosUsuario = 300; // Este valor puede provenir de una base de datos o del estado del usuario

// Función para cargar las recompensas desde la variable
function cargarRecompensas() {
    const contenedor = document.getElementById("recompensas-lista");
    contenedor.innerHTML = '';  // Limpiar el contenedor antes de agregar nuevos elementos

    // Agregar las recompensas a la lista utilizando los datos del array
    recompensasDisponibles.forEach((recompensa) => {
        let divRecompensa = document.createElement("div");
        divRecompensa.classList.add("recompensa-item");

        // Crear el contenido con el nombre, descripción y puntos
        divRecompensa.innerHTML = `
            <h3>${recompensa.nombre}</h3>
            <p>${recompensa.descripcion}</p>
            <p><strong>${recompensa.puntos} puntos</strong></p>
            <button onclick="reclamarRecompensa(${recompensa.puntos})" id="btn-${recompensa.nombre}" 
            ${recompensa.puntos > puntosUsuario ? "disabled" : ""}>Reclamar</button>
        `;
        contenedor.appendChild(divRecompensa);
    });

    // Actualizar los puntos acumulados
    const puntosElement = document.getElementById("puntos");
    puntosElement.textContent = puntosUsuario; // Mostrar puntos acumulados

    // Agregar botón de recompensa solo si isAdmin es true
    if (isAdmin) {
        const btnAgregarRecompensa = document.createElement("button");
        btnAgregarRecompensa.textContent = "Agregar Recompensa";
        btnAgregarRecompensa.onclick = agregarRecompensaAdmin;
        contenedor.appendChild(btnAgregarRecompensa);
    }
}

// Función para reclamar la recompensa
function reclamarRecompensa(puntosRecompensa) {
    // Verificar si el usuario tiene suficientes puntos
    if (puntosUsuario >= puntosRecompensa) {
        puntosUsuario -= puntosRecompensa;  // Reducir los puntos del usuario
        alert("¡Recompensa reclamada exitosamente!");

        // Recargar las recompensas para reflejar los cambios en los puntos
        cargarRecompensas();
    } else {
        alert("No tienes suficientes puntos para reclamar esta recompensa.");
    }
}


// Llamar a la función cargarRecompensas cuando sea necesario
cargarRecompensas();

// Función para canjear una recompensa
function canjearRecompensa(index) {
    const recompensa = recompensasDisponibles[index];

    if (puntosUsuario >= recompensa.puntos) {
        puntosUsuario -= recompensa.puntos; // Restar los puntos del usuario
        alert(`¡Has canjeado la recompensa "${recompensa.nombre}"!`);
        cargarRecompensas(); // Actualizar la lista de recompensas
    } else {
        alert("No tienes suficientes puntos para canjear esta recompensa.");
    }
}

window.onload = function() {
    if (typeof initMap === "function") {
        initMap(); // Ensure the map is initialized
    }
    cargarRetosDisponibles();
    cargarMisRetos();
    cargarRecompensas();
};

// Función para iniciar un reto
function iniciarReto(index) {
    const reto = retos[index];

    // Cambiar el estado del reto a "en progreso"
    alert(`¡Reto "${reto.nombre}" activado! Ahora debes completar este reto.`);

    // Asumimos que el reto ha sido completado (en un caso real sería cuando el usuario suba evidencia o lo verifiquemos de alguna manera)
    completarReto(index);
}


// Función para completar un reto
function completarReto(index) {
    const reto = retos[index];

    // Actualizar el estado del reto a completado
    reto.completado = true;

    // Sumar los puntos al usuario
    puntosUsuario += reto.puntos;

    // Mostrar mensaje de éxito
    alert(`¡Felicidades! Has completado el reto "${reto.nombre}" y has recibido ${reto.puntos} puntos.`);

    // Actualizar la interfaz de los retos y los puntos
    cargarRetos();
}

// Array de retos activos del usuario
let retosActivos = [];

// Función para activar un reto
function activarReto(index) {
    const reto = retosDisponibles[index];
    const retoActivo = {
        nombre: reto.nombre,
        descripcion: reto.descripcion,
        puntos: reto.puntos,
        completado: false,
        evidencias: [],  // El array de evidencias que se suban
    };

    // Añadir el reto a los retos activos del usuario
    retosActivos.push(retoActivo);

    // Mostrar en el perfil los retos activos
    cargarMisRetos();

    alert(`¡Reto "${reto.nombre}" activado! Ahora debes completarlo y subir evidencia.`);
}

// Función para cargar los retos activos del perfil
function cargarMisRetos() {
    const misRetosDiv = document.getElementById('mis-retos');
    misRetosDiv.innerHTML = ""; // Limpiar la lista antes de agregar los retos activos

    retosActivos.forEach((reto, index) => {
        const div = document.createElement('div');
        div.classList.add('reto-activo');
        div.innerHTML = `
            <h4>${reto.nombre}</h4>
            <p>${reto.descripcion}</p>
            <p><strong>${reto.puntos} puntos</strong></p>
            <input type="file" id="evidencia-${index}" accept="image/*" style="display: none;" onchange="handleEvidenciaUpload(event, ${index})">
            <button onclick="document.getElementById('evidencia-${index}').click()" ${reto.completado ? "disabled" : ""}>Subir Evidencia</button>
            <button onclick="cancelarReto(${index})">Cancelar Reto</button>
            ${reto.completado ? `<p>Reto completado. Evidencias entregadas.</p>` : ""}
            <div id="preview-${index}" style="margin-top: 10px;"></div>
        `;
        misRetosDiv.appendChild(div);
    });
}

// Manejar la carga de evidencia
function handleEvidenciaUpload(event, index) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            // Mostrar una vista previa de la imagen
            const previewDiv = document.getElementById(`preview-${index}`);
            previewDiv.innerHTML = `<img src="${e.target.result}" alt="Vista previa" style="max-width: 100%; height: auto;">`;

            // Actualizar el reto como completado
            retosActivos[index].completado = true;
            retosActivos[index].evidencia = e.target.result; // Guardar la imagen como base64
            cargarMisRetos(); // Recargar la lista para reflejar los cambios
        };
        reader.readAsDataURL(file);
    }
}





function cargarRetos() {
    const retosLista = document.getElementById('retos-lista');
    retosLista.innerHTML = ""; // Limpiar la lista antes de agregar nuevos retos

    retosDisponibles.forEach((reto, index) => {
        const div = document.createElement('div');
        div.classList.add('reto');
        div.innerHTML = `
            <h3>${reto.nombre}</h3>
            <p>${reto.descripcion}</p>
            <p><strong>${reto.puntos} puntos</strong></p>
            <button onclick="enviarEvidencia(${index})">Enviar Evidencia</button>
        `;
        retosLista.appendChild(div);
    });
}

function cargarEvidenciasAdmin() {
    const evidenciasLista = document.getElementById('evidencias-lista');
    if (!evidenciasLista) {
      console.error("El elemento 'evidencias-lista' no existe en el DOM.");
      return;
    }
  
    // Obtener todos los usuarios
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  
    evidenciasLista.innerHTML = "<h3>Evidencias Pendientes</h3>";
    let evidenciasPendientes = 0;
  
    usuarios.forEach(usuario => {
      if (usuario.evidencias && usuario.evidencias.length > 0) {
        usuario.evidencias.forEach((evidencia, index) => {
          if (evidencia.estado === "Pendiente") {
            evidenciasPendientes++;
  
            const evidenciaItem = document.createElement('div');
            evidenciaItem.classList.add('evidencia-item');
            evidenciaItem.innerHTML = `
              <p><strong>Usuario:</strong> ${usuario.nombre}</p>
              <p><strong>Reto:</strong> ${evidencia.reto.nombre}</p>
              <p><strong>Evidencia:</strong> ${evidencia.evidencia}</p>
              <button onclick="aceptarEvidencia('${usuario.email}', ${index})">Aceptar</button>
              <button onclick="rechazarEvidencia('${usuario.email}', ${index})">Rechazar</button>
              <hr>
            `;
            evidenciasLista.appendChild(evidenciaItem);
          }
        });
      }
    });
  
    if (evidenciasPendientes === 0) {
      evidenciasLista.innerHTML += "<p>No hay evidencias pendientes.</p>";
    }
  }
  
  
  document.addEventListener('DOMContentLoaded', function () {
    if (localStorage.getItem('isAdmin') === "true") {
      cargarEvidenciasAdmin();
    }
  });

  function aceptarEvidencia(email, evidenciaIndex) {
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const usuario = usuarios.find(user => user.email === email);
  
    if (usuario) {
      const evidencia = usuario.evidencias[evidenciaIndex];
      evidencia.estado = "Aceptada"; // Cambiar estado
      usuario.puntos += evidencia.reto.puntos; // Asignar puntos
  
      // Guardar cambios en localStorage
      localStorage.setItem("usuarios", JSON.stringify(usuarios));
      alert(`Evidencia aceptada. ${evidencia.reto.puntos} puntos asignados a ${usuario.nombre}.`);
      cargarEvidenciasAdmin(); // Actualizar la lista
    }
  }
  
  function rechazarEvidencia(email, evidenciaIndex) {
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const usuario = usuarios.find(user => user.email === email);
  
    if (usuario) {
      const evidencia = usuario.evidencias[evidenciaIndex];
      evidencia.estado = "Rechazada"; // Cambiar estado
  
      // Guardar cambios en localStorage
      localStorage.setItem("usuarios", JSON.stringify(usuarios));
      alert(`Evidencia rechazada. El reto de ${usuario.nombre} no cumple los requisitos.`);
      cargarEvidenciasAdmin(); // Actualizar la lista
    }
  }

// Función para actualizar los puntos del usuario en la interfaz (simulada)
function cargarPuntosUsuario(usuarioId) {
    const usuario = usuarios.find(u => u.id === usuarioId);
    if (usuario) {
        // Aquí se simula actualizar el elemento de la interfaz donde aparecen los puntos del usuario
        const puntosElement = document.getElementById(`puntos-${usuarioId}`);
        if (puntosElement) {
            puntosElement.textContent = `Puntos: ${usuario.puntos}`;
        }
    }
}


// Función para cargar los puntos del usuario en la interfaz
function cargarPuntosUsuario(usuarioId) {
    const usuario = usuarios.find(u => u.id === usuarioId);
    const puntosElement = document.getElementById("puntos");
    puntosElement.textContent = usuario.puntos; // Mostrar puntos acumulados
}

// Llamar a cargar los retos del perfil al cargar la página
window.onload = function() {
    cargarRetosDisponibles();
    cargarMisRetos();
};

function subirEvidencia(index) {
    const retosActivos = JSON.parse(localStorage.getItem("retosActivos")) || [];
    const reto = retosActivos[index];

    if (!reto) {
        alert("No se encontró el reto.");
        return;
    }

    // Crear un formulario para subir evidencia
    const evidencia = prompt("Introduce la evidencia del reto (puede ser un enlace o una descripción):");
    if (evidencia) {
        reto.evidencias = reto.evidencias || [];
        reto.evidencias.push(evidencia);

        // Cambiar el estado de completado cuando se suban las evidencias
        if (reto.evidencias.length > 0) {
            reto.completado = true;
            alert(`¡Felicidades! Has completado el reto "${reto.nombre}".`);
        }

        // Guardar los cambios en localStorage
        localStorage.setItem("retosActivos", JSON.stringify(retosActivos));
    } else {
        alert("No se subió ninguna evidencia.");
    }
}


function enviarEvidencia(index) {
    const retosDisponibles = JSON.parse(localStorage.getItem("retosDisponibles")) || [];
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const usuarioActual = usuarios[0]; // Supongamos que es el primer usuario (ajusta esta lógica según sea necesario)
    
    if (!usuarioActual || !retosDisponibles[index]) {
        alert("Hubo un problema al encontrar el reto o el usuario.");
        return;
    }

    const evidencia = prompt("Por favor, describe tu evidencia (puede ser un enlace o una breve descripción).");
    if (evidencia) {
        usuarioActual.evidencias = usuarioActual.evidencias || [];
        usuarioActual.evidencias.push({
            reto: retosDisponibles[index].nombre,
            evidencia: evidencia,
            estado: "Pendiente"
        });

        // Guardar los cambios en localStorage
        usuarios[0] = usuarioActual;
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
        alert("Evidencia enviada y guardada correctamente.");
    } else {
        alert("No se subió ninguna evidencia.");
    }
}





// Función para cancelar un reto
function cancelarReto(index) {
    const confirmado = confirm("¿Estás seguro de que quieres cancelar este reto?");
    if (confirmado) {
        retosActivos.splice(index, 1); // Eliminar el reto de los activos
        cargarMisRetos(); // Actualizar los retos activos
        alert("Reto cancelado.");
    }
}

// Llamamos a cargar los retos disponibles cuando cargue la página
cargarRetosDisponibles();

// Llamamos a cargar los retos del perfil cuando se cargue la página
cargarMisRetos();

// Llamamos a cargar los retos cuando cargue la página
cargarRetos();



// Evento para el botón de "Limpiar Datos"
document.querySelector('.clear-button').addEventListener('click', eliminarTodosMarcadores);


let solicitudesPendientes = []; // Lista de solicitudes pendientes de revisión por los administradores

// Función para entregar el reto al administrador
function entregarRetoAlAdmin(index) {
    const reto = retosActivos[index];
    
    if (reto.completado && reto.evidencias.length > 0) {
        // Push the challenge to a global array that the admin reviews
        solicitudesPendientes.push({
            nombre: reto.nombre,
            descripcion: reto.descripcion,
            evidencias: reto.evidencias,
            puntos: reto.puntos,
            usuario: "UsuarioEjemplo", // Replace with the actual logged-in user's name
        });

        // Remove the challenge from the user's active list
        retosActivos.splice(index, 1);

        // Update the UI
        cargarMisRetos();

        alert("¡Reto entregado! El administrador revisará tus evidencias y asignará los puntos.");
    } else {
        alert("Debes completar el reto y subir al menos una evidencia antes de entregarlo.");
    }
}


//

function cerrarSesion() {
    // Limpia los datos del usuario, por ejemplo, en el localStorage
    localStorage.removeItem('usuario');

    // Redirige a la página de inicio de sesión o a la página de inicio
    window.location.href = 'login.html'; // Cambia 'index.html' a la URL de tu página de inicio de sesión
}

document.addEventListener('DOMContentLoaded', function() {
    const isAdmin = localStorage.getItem('isAdmin') === "true";

    if (isAdmin) {
        console.log("Admin mode is active"); // Confirm admin mode is active

        // Show the admin link
        const adminLink = document.getElementById('admin-link');
        if (adminLink) {
            adminLink.style.display = 'inline';
            console.log("Admin link is shown");
        } else {
            console.error("Admin link element not found!");
        }

        // Show admin-only sections
        const adminSections = document.querySelectorAll('.admin-only');
        if (adminSections.length > 0) {
            adminSections.forEach(section => {
                section.style.display = 'block';
                console.log(`Showing admin section: ${section.id}`); // Log each admin section
            });
        } else {
            console.error("No admin sections found!");
        }

        // Load admin-specific data
        cargarUsuariosAdmin();
        cargarRetosUsuarios();
    } else {
        // Hide admin-only sections for regular users
        document.querySelectorAll('.admin-only').forEach(section => {
            section.style.display = 'none';
        });
    }

    // Load general data for both admins and regular users
    cargarRecompensas();
    cargarRetosDisponibles();
});





function cargarUsuariosAdmin() {
    const usuariosLista = document.getElementById('usuarios-lista');
    if (!usuariosLista) {
      console.error("El elemento 'usuarios-lista' no existe en el DOM.");
      return;
    }
  
    // Obtener los usuarios desde localStorage
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  
    usuariosLista.innerHTML = "<h3>Usuarios Registrados</h3>";
  
    if (usuarios.length === 0) {
      usuariosLista.innerHTML += "<p>No hay usuarios registrados.</p>";
      return;
    }
  
    usuarios.forEach(usuario => {
      const usuarioItem = document.createElement('div');
      usuarioItem.classList.add('usuario-item');
      usuarioItem.innerHTML = `
        <p><strong>Nombre:</strong> ${usuario.nombre || "N/A"}</p>
        <p><strong>ID:</strong> ${usuario.id || "N/A"}</p>
        <p><strong>Puntos:</strong> ${usuario.puntos || 0}</p>
        <hr>
      `;
      usuariosLista.appendChild(usuarioItem);
    });
  }
  


document.addEventListener('DOMContentLoaded', function() {
    if (localStorage.getItem('isAdmin') === "true") {
        cargarUsuariosAdmin();
        cargarEvidenciasAdmin();
    }
});



function cargarRetosUsuarios() {
    const retosUsuariosDiv = document.getElementById('retos-usuarios');
    if (!retosUsuariosDiv) {
        console.error("retos-usuarios element not found!");
        return;
    }
    console.log("Populating user challenges...");

    retosUsuariosDiv.innerHTML = "<h3>Retos Enviados por Usuarios</h3>";
    if (solicitudesPendientes.length === 0) {
        retosUsuariosDiv.innerHTML += "<p>No hay retos enviados por los usuarios.</p>";
    } else {
        solicitudesPendientes.forEach((solicitud, index) => {
            const retoDiv = document.createElement('div');
            retoDiv.classList.add('reto-item');
            retoDiv.innerHTML = `
                <h4>Usuario: ${solicitud.usuario}</h4>
                <p>Reto: ${solicitud.nombre}</p>
                <p>Evidencias: ${solicitud.evidencias.join(", ")}</p>
                <button onclick="aprobarReto(${index})">Aprobar</button>
                <button onclick="rechazarReto(${index})">Rechazar</button>
            `;
            retosUsuariosDiv.appendChild(retoDiv);
        });
    }
}

// Función para aprobar retos y asignar puntos
function aprobarReto(usuarioId, evidenciaIndex) {
    const usuario = usuarios.find(u => u.id === usuarioId);
    const evidencia = usuario.evidencias[evidenciaIndex];

    // Sumar puntos al usuario
    usuario.puntos += evidencia.reto.puntos;

    // Cambiar el estado de la evidencia
    evidencia.estado = "Aprobada";

    alert(`Evidencia aprobada. ${evidencia.reto.puntos} puntos asignados a ${usuario.nombre}.`);

    // Actualizar la lista y refrescar la interfaz
    cargarRetosUsuarios();
    cargarUsuariosAdmin();
}

// Función para rechazar retos
function rechazarReto(usuarioId, evidenciaIndex) {
    const usuario = usuarios.find(u => u.id === usuarioId);
    const evidencia = usuario.evidencias[evidenciaIndex];

    // Cambiar el estado de la evidencia
    evidencia.estado = "Rechazada";

    alert(`Evidencia rechazada. La evidencia de ${usuario.nombre} no cumple los requisitos.`);

    // Actualizar la lista y refrescar la interfaz
    cargarRetosUsuarios();
}



// Cargar retos pendientes en el panel de administración
function cargarRetosUsuarios() {
    const retosPendientesDiv = document.getElementById('retos-pendientes');

    retosPendientesDiv.innerHTML = ""; // Limpiar contenido

    usuarios.forEach((usuario, usuarioIndex) => {
        usuario.evidencias.forEach((evidencia, evidenciaIndex) => {
            if (evidencia.estado === "Pendiente") {
                const div = document.createElement('div');
                div.classList.add('reto');
                div.innerHTML = `
                    <h3>${evidencia.reto.nombre}</h3>
                    <p><strong>Usuario:</strong> ${usuario.nombre}</p>
                    <p><strong>Puntos del reto:</strong> ${evidencia.reto.puntos}</p>
                    <div class="buttons">
                        <button class="accept" onclick="aprobarReto(${usuario.id}, ${evidenciaIndex})">Aprobar</button>
                        <button class="reject" onclick="rechazarReto(${usuario.id}, ${evidenciaIndex})">Rechazar</button>
                        <button class="reward" onclick="mostrarOpcionesRecompensas(${usuario.id})">Dar Recompensa</button>
                    </div>
                `;
                retosPendientesDiv.appendChild(div);
            }
        });
    });
}

// Mostrar opciones de recompensas para un usuario
function mostrarOpcionesRecompensas(usuarioId) {
    const recompensasDisponibles = [
        { nombre: "Descuento en compras", costo: 50 },
        { nombre: "Entrada a evento exclusivo", costo: 100 },
        { nombre: "Regalo especial", costo: 200 },
    ];

    let opciones = "Selecciona una recompensa:\n";
    recompensasDisponibles.forEach((recompensa, index) => {
        opciones += `${index + 1}. ${recompensa.nombre} - ${recompensa.costo} puntos\n`;
    });

    const seleccion = prompt(opciones);
    const recompensaSeleccionada = recompensasDisponibles[parseInt(seleccion) - 1];

    if (recompensaSeleccionada) {
        otorgarRecompensa(usuarioId, recompensaSeleccionada);
    } else {
        alert("Selección inválida o cancelada.");
    }
}

function agregarRecompensaAdmin() {
    const nombre = prompt("Ingrese el nombre de la recompensa:");
    const puntos = parseInt(prompt("Ingrese los puntos necesarios para la recompensa:"), 10);
    const descripcion = prompt("Ingrese la descripción de la recompensa:");

    if (nombre && puntos && descripcion) {
        recompensasDisponibles.push({ nombre, puntos, descripcion });
        cargarRecompensas();  // Actualizar lista de recompensas
        alert("Recompensa agregada exitosamente.");
    }
}

function agregarRetoAdmin() {
    const nombre = prompt("Ingrese el nombre del reto:");
    const descripcion = prompt("Ingrese la descripción del reto:");
    const puntos = parseInt(prompt("Ingrese los puntos otorgados por el reto:"), 10);

    if (nombre && descripcion && puntos) {
        retosDisponibles.push({ nombre, descripcion, puntos, completado: false });
        cargarRetosDisponibles();  // Actualizar lista de retos
        alert("Reto agregado exitosamente.");
    }
}




// Función para ajustar visibilidad de los elementos del administrador
function checkAdminVisibility() {
    // Si el usuario es administrador
    if (isAdmin) {
        // Mostrar el enlace de administración en el menú
        document.getElementById("admin-link").style.display = "block";

        // Mostrar todos los elementos exclusivos para administradores
        const adminElements = document.querySelectorAll('.admin-only');
        adminElements.forEach(element => {
            element.style.display = 'block';
        });
    } else {
        // Asegurarse de que los elementos de administración están ocultos para otros usuarios
        const adminElements = document.querySelectorAll('.admin-only');
        adminElements.forEach(element => {
            element.style.display = 'none';
        });
    }
}

// Ejecutar la función de visibilidad de administrador al cargar la página
window.onload = checkAdminVisibility;